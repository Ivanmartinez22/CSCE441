Ivan Martinez
UIN: 529006731
CSCE441-500
I was able to implement all. I turned this in a day late using my last late day. 

